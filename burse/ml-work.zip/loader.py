# market, em, code – об этих параметрах, упоминал ранее, при обращении к функции их значения будут приниматься из файла.
# df, mf, yf, from, dt, mt, yt, to – это параметры времени.
# p — период котировок (тики, 1 мин., 5 мин., 10 мин., 15 мин., 30 мин., 1 час, 1 день, 1 неделя, 1 месяц)
# e – расширение получаемого файла; возможны варианты — .txt либо .csv
# dtf — формат даты (1 — ггггммдд, 2 — ггммдд, 3 — ддммгг, 4 — дд/мм/гг, 5 — мм/дд/гг)
# tmf — формат времени (1 — ччммсс, 2 — ччмм, 3 — чч: мм: сс, 4 — чч: мм)
# MSOR — выдавать время (0 — начала свечи, 1 — окончания свечи)
# mstimever — выдавать время (НЕ московское — mstimever=0; московское — mstime='on', mstimever='1')
# sep — параметр разделитель полей (1 — запятая (,), 2 — точка (.), 3 — точка с запятой (;), 4 — табуляция (»), 5 — пробел ( ))
# sep2 — параметр разделитель разрядов (1 — нет, 2 — точка (.), 3 — запятая (,), 4 — пробел ( ), 5 — кавычка ('))
# datf — Перечень получаемых данных (#1 — TICKER, PER, DATE, TIME, OPEN, HIGH, LOW, CLOSE, VOL; #2 — TICKER, PER, DATE, TIME, OPEN, HIGH, LOW, CLOSE; #3 — TICKER, PER, DATE, TIME, CLOSE, VOL; #4 — TICKER, PER, DATE, TIME, CLOSE; #5 — DATE, TIME, OPEN, HIGH, LOW, CLOSE, VOL; #6 — DATE, TIME, LAST, VOL, ID, OPER).
# at — добавлять заголовок в файл (0 — нет, 1 — да)


import urllib
import pandas as pd 
import numpy as np
import datetime as dt

code='tratata'
e='.csv'
market='200'
em='17273'
p='3'
yf='2017'
yt='2017'
month_start='05'
day_start='20'
month_end='06'
day_end='20'
dtf='1'
tmf='1'
MSOR='1'
mstimever='0'
sep='1'
sep2='3'
datf='1'
at='1'


year_start=yf[2:]
year_end=yt[2:]
mf=(int(month_start.replace('0','')))-1
mt=(int(month_end.replace('0','')))-1
df=(int(day_start.replace('0','')))-1
dt=(int(day_end.replace('0','')))-1

page = urllib.request.urlopen('http://export.finam.ru/'+str(code)+'_'+str(year_start)+str(month_start)+str(day_start)+'_'+str(year_end)+str(month_end)+str(day_end)+str(e)+'?market='+str(market)+'&em='+str(em)+'&code='+str(code)+'&apply=0&df='+str(df)+'&mf='+str(mf)+'&yf='+str(yf)+'&from='+str(day_start)+'.'+str(month_start)+'.'+str(yf)+'&dt='+str(dt)+'&mt='+str(mt)+'&yt='+str(yt)+'&to='+str(day_end)+'.'+str(month_end)+'.'+str(yt)+'&p='+str(p)+'&f='+str(code)+'_'+str(year_start)+str(month_start)+str(day_start)+'_'+str(year_end)+str(month_end)+str(day_end)+'&e='+str(e)+'&cn='+str(code)+'&dtf='+str(dtf)+'&tmf='+str(tmf)+'&MSOR='+str(MSOR)+'&mstimever='+str(mstimever)+'&sep='+str(sep)+'&sep2='+str(sep2)+'&datf='+str(datf)+'&at='+str(at))
f = open(str(code)+str(e), "wb")
content = page.read()
f.write(content)
f.close()
p2=pd.read_csv("htmlData_prepared.csv")
params=pd.read_csv("function_parameters.csv", names=['tool_name', 'market', 'link', 'tool_value', 'tool_code', 'market_index', 'market_class'])

params.sort_values(by=['tool_value'])

def DownloadQuotations(code, date_start, date_end, period, starttorfinisht, is_ms_time, data_format, is_header):
    
    params=pd.read_csv("function_parameters.csv", names=['tool_name', 'market', 'link', 'tool_value', 'tool_code', 'market_index', 'market_class'])
    e='.csv'
    market=''


    page = urllib.request.urlopen('http://export.finam.ru/'+str(code)+'_'+str(year_start)+str(month_start)+str(day_start)+'_'+str(year_end)+str(month_end)+str(day_end)+str(e)+'?market='+str(market)+'&em='+str(em)+'&code='+str(code)+'&apply=0&df='+str(df)+'&mf='+str(mf)+'&yf='+str(yf)+'&from='+str(day_start)+'.'+str(month_start)+'.'+str(yf)+'&dt='+str(dt)+'&mt='+str(mt)+'&yt='+str(yt)+'&to='+str(day_end)+'.'+str(month_end)+'.'+str(yt)+'&p='+str(p)+'&f='+str(code)+'_'+str(year_start)+str(month_start)+str(day_start)+'_'+str(year_end)+str(month_end)+str(day_end)+'&e='+str(e)+'&cn='+str(code)+'&dtf='+str(dtf)+'&tmf='+str(tmf)+'&MSOR='+str(MSOR)+'&mstimever='+str(mstimever)+'&sep='+str(sep)+'&sep2='+str(sep2)+'&datf='+str(datf)+'&at='+str(at))
    f = open(str(code)+str(e), "wb")
    content = page.read()
    f.write(content)
    f.close()

qq = quotes(code,year_start,month_start,day_start,year_end,month_end,day_end,e,market,em,df,mf,yf,dt,mt,yt,p,dtf,tmf,MSOR,mstimever,sep,sep2,datf,at)